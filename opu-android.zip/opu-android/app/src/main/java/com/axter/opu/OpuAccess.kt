package com.axter.opu

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.SearchManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.media.AudioManager
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.ByteArrayOutputStream
import kotlin.coroutines.resume

/**
 * Opu's hands. Once you switch this service on in Accessibility settings,
 * the assistant can tap, swipe, type, press Back/Home, open apps and read the screen.
 */
class OpuAccess : AccessibilityService() {

    companion object {
        @Volatile var inst: OpuAccess? = null
        val ready get() = inst != null
    }

    override fun onServiceConnected() { inst = this }
    override fun onUnbind(intent: Intent?): Boolean { inst = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    val screenW get() = resources.displayMetrics.widthPixels
    val screenH get() = resources.displayMetrics.heightPixels

    fun tap(x: Float, y: Float) = gesture(Path().apply { moveTo(x, y) }, 60)

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long = 350) =
        gesture(Path().apply { moveTo(x1, y1); lineTo(x2, y2) }, ms)

    private fun gesture(p: Path, ms: Long) {
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, ms)).build()
        dispatchGesture(g, null, null)
    }

    fun scroll(down: Boolean) {
        val x = screenW / 2f
        val a = screenH * 0.7f
        val b = screenH * 0.3f
        if (down) swipe(x, a, x, b) else swipe(x, b, x, a)
    }

    fun back() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun home() = performGlobalAction(GLOBAL_ACTION_HOME)
    fun recents() = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun notifications() = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
    fun quickSettings() = performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)

    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: findEditable(root) ?: return false
        val b = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    private fun findEditable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (n.isEditable) return n
        for (i in 0 until n.childCount) n.getChild(i)?.let { c -> findEditable(c)?.let { return it } }
        return null
    }

    /** Taps the first visible thing whose text or description contains [text]. */
    fun tapText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val hit = root.findAccessibilityNodeInfosByText(text).firstOrNull() ?: return false
        var n: AccessibilityNodeInfo? = hit
        while (n != null) {
            if (n.isClickable && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            n = n.parent
        }
        val r = Rect(); hit.getBoundsInScreen(r)
        tap(r.exactCenterX(), r.exactCenterY())
        return true
    }

    /** Text view of the screen: what is written and where, so Opu can read and tap by position. */
    fun dump(): String {
        val root = rootInActiveWindow ?: return "(screen not readable)"
        val sb = StringBuilder("screen ${screenW}x$screenH, app=${root.packageName}\n")
        fun walk(n: AccessibilityNodeInfo, d: Int) {
            if (sb.length > 6000) return
            val t = (n.text ?: n.contentDescription)?.toString()
            if (!t.isNullOrBlank() || n.isClickable || n.isEditable) {
                val r = Rect(); n.getBoundsInScreen(r)
                sb.append(if (n.isEditable) "[input] " else if (n.isClickable) "[tap] " else "").append(t ?: "").append(" @").append(r.centerX()).append(',').append(r.centerY()).append('\n')
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it, d + 1) }
        }
        walk(root, 0)
        return sb.toString()
    }

    /** Screenshot as base64 JPEG (Android 11+). */
    suspend fun screenshotB64(): String? = suspendCancellableCoroutine { cont ->
        takeScreenshot(0, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(r: ScreenshotResult) {
                try {
                    val hw = Bitmap.wrapHardwareBuffer(r.hardwareBuffer, r.colorSpace)
                    val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                    r.hardwareBuffer.close()
                    if (bmp == null) { cont.resume(null); return }
                    val w = 720
                    val s = Bitmap.createScaledBitmap(bmp, w, (bmp.height * w.toFloat() / bmp.width).toInt(), true)
                    val o = ByteArrayOutputStream()
                    s.compress(Bitmap.CompressFormat.JPEG, 70, o)
                    cont.resume(Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP))
                } catch (e: Exception) { cont.resume(null) }
            }
            override fun onFailure(code: Int) { cont.resume(null) }
        })
    }

    /** Opens an installed app by its name ("whatsapp", "settings", "camera"...). */
    fun openApp(name: String): Boolean {
        val pm = packageManager
        val q = name.lowercase().trim()
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(i, 0)
        val best = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            ?: apps.firstOrNull { q.contains(it.loadLabel(pm).toString().lowercase()) && it.loadLabel(pm).length > 2 }
            ?: return false
        val launch = pm.getLaunchIntentForPackage(best.activityInfo.packageName) ?: return false
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(launch)
        return true
    }

    fun openUrl(url: String) {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun mediaKey(code: Int) {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    /** Asks the default music app to play something. Some apps show themselves briefly. */
    fun playMusic(query: String): Boolean {
        val base = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
            .putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
            .putExtra(SearchManager.QUERY, query)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        for (pkg in listOf("com.spotify.music", "com.google.android.apps.youtube.music", "com.jio.media.jiobeats", "com.gaana", null)) {
            try {
                val i = Intent(base)
                if (pkg != null) {
                    packageManager.getPackageInfo(pkg, 0)
                    i.setPackage(pkg)
                }
                startActivity(i)
                return true
            } catch (e: Exception) { }
        }
        return false
    }
}
