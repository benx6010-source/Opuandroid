package com.axter.opu

import android.Manifest
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.io.File

/** Setup screen: permissions, keys, 3D model, start/stop. Built in code so there is no layout file to break. */
class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var col: LinearLayout

    private val pickModel = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null) return@registerForActivityResult
        try {
            val dir = File(filesDir, "model").apply { mkdirs() }
            contentResolver.openInputStream(uri)!!.use { i -> File(dir, "model.glb").outputStream().use { o -> i.copyTo(o) } }
            toast("3D model saved. Call Opu to see her.")
        } catch (e: Exception) { toast("Couldn't read that file") }
        refresh()
    }
    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh() }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val sv = ScrollView(this); sv.setBackgroundColor(Color.BLACK)
        col = LinearLayout(this); col.orientation = LinearLayout.VERTICAL
        val pad = (resources.displayMetrics.density * 18).toInt(); col.setPadding(pad, pad * 2, pad, pad * 2)
        sv.addView(col); setContentView(sv)
        build()
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun text(s: String, size: Float, bold: Boolean = false, color: Int = Color.WHITE): TextView =
        TextView(this).apply { text = s; textSize = size; setTextColor(color); if (bold) setTypeface(null, Typeface.BOLD); setPadding(0, 8, 0, 8) }

    private fun btn(label: String, fn: () -> Unit): Button =
        Button(this).apply { text = label; isAllCaps = false; setOnClickListener { fn() } }

    private fun field(hint: String, key: String, secret: Boolean = false): EditText =
        EditText(this).apply {
            this.hint = hint; setText(Store.get(this@MainActivity, key, if (key == "user_name") "Axter" else if (key == "opu_name") "Opu" else ""))
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            if (secret) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine()
            addTextChangedListener(object : android.text.TextWatcher {
                override fun afterTextChanged(s: android.text.Editable?) { Store.put(this@MainActivity, key, s.toString().trim()) }
                override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
                override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            })
        }

    private fun build() {
        col.removeAllViews()
        col.addView(text("Opu", 34f, true))
        status = text("", 14f, color = Color.LTGRAY); col.addView(status)

        col.addView(text("1. Permissions", 18f, true))
        col.addView(btn("Allow microphone, camera, notifications") {
            perms.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA, Manifest.permission.POST_NOTIFICATIONS))
        })
        col.addView(btn("Allow Opu to appear over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        col.addView(btn("Turn on screen control (Accessibility → Opu)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(btn("Let Opu keep running in background (battery)") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        col.addView(text("Android shows a warning for Accessibility. That is normal for assistants. Opu only acts when you ask, and asks you before sending, buying or deleting.", 12f, color = Color.GRAY))

        col.addView(text("2. Brain", 18f, true))
        col.addView(field("Gemini API key (aistudio.google.com/apikey)", "gemini_key", true))
        col.addView(field("Your name", "user_name"))
        col.addView(field("Her name", "opu_name"))

        col.addView(text("3. Her body", 18f, true))
        col.addView(text("Pick a .glb or .vrm 3D file that you made or have the right to use. Without one, she appears as the cloud.", 12f, color = Color.GRAY))
        col.addView(btn("Choose 3D model from files") { pickModel.launch(arrayOf("*/*")) })
        col.addView(btn("Remove 3D model") { File(filesDir, "model/model.glb").delete(); refresh() })

        col.addView(text("4. Start", 18f, true))
        col.addView(btn("Start listening for “Opu”") {
            ContextCompat.startForegroundService(this, Intent(this, OpuService::class.java)); refresh()
        })
        col.addView(btn("Call Opu now (no voice needed)") {
            ContextCompat.startForegroundService(this, Intent(this, OpuService::class.java).setAction(OpuService.CALL)); moveTaskToBack(true)
        })
        col.addView(btn("Stop") { stopService(Intent(this, OpuService::class.java)); refresh() })

        col.addView(text("Say “Opu” to bring her. Say “go”, or double-tap her, to send her away. Drag her to move. Say “look at me” and she takes one front-camera photo to see you.", 13f, color = Color.LTGRAY))
        refresh()
    }

    private fun refresh() {
        fun ok(b: Boolean) = if (b) "✓" else "✗"
        val mic = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == 0
        val cam = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == 0
        status.text = "${ok(mic)} microphone   ${ok(cam)} camera   ${ok(Settings.canDrawOverlays(this))} over other apps\n" +
            "${ok(OpuAccess.ready)} screen control   ${ok(Store.geminiKey(this).isNotBlank())} Gemini key   ${ok(File(filesDir, "model/model.glb").exists())} 3D model\n" +
            if (OpuService.running) "Listening for “Opu”." else "Not listening yet."
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
